import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent  implements OnInit{
  fullText = 'FULL STACK SOFTWARE DEVELOPER.';
  displayText = '';
  isDeleting = false;
  loopNum = 0;
  typingSpeed = 100;
  fullCode: string = `
  <span class="keyword">function</span> <span class="function-name">getInfo</span>() {
    <span class="keyword">return</span> {
      <span class="property">name</span>: <span class="string">"Tu Nombre"</span>,
      <span class="property">age</span>: <span class="number">28</span>,
      <span class="property">location</span>: <span class="string">"Buenos Aires, Argentina"</span>,
      <span class="property">email</span>: <span class="string">"tuemail@gmail.com"</span>,
      <span class="property">role</span>: <span class="string">"Full Stack Developer"</span>
    };
  }
  `.trim();
  displayedCode: string = '';
  currentIndex: number = 0;

  ngOnInit() {
    this.typeEffect();
    
  }
 typeEffectdatos() {
    if (this.currentIndex < this.fullCode.length) {
      this.displayedCode += this.fullCode[this.currentIndex++];
      setTimeout(() => this.typeEffectdatos(), 10);
    }
  }
  typeEffect() {
    if (this.displayText.length < this.fullText.length) {
      this.displayText += this.fullText[this.displayText.length];
      setTimeout(() => this.typeEffect(), this.typingSpeed);
    } else {
      
      this.typeEffectdatos();
    }
  }

}
