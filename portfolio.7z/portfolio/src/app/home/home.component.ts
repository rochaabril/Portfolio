import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent  implements OnInit{
  fullText = 'FULL STACK SOFTWARE DEVELOPER.';
  displayText = '';
  isDeleting = false;
  loopNum = 0;
  typingSpeed = 100;

  ngOnInit() {
    this.typeEffect();
  }

  typeEffect() {
    const current = this.loopNum % this.fullText.length;
    const fullTxt = this.fullText;

    if (this.isDeleting) {
      this.displayText = fullTxt.substring(0, this.displayText.length - 1);
    } else {
      this.displayText = fullTxt.substring(0, this.displayText.length + 1);
    }

    let delta = this.isDeleting ? 50 : this.typingSpeed;

    if (!this.isDeleting && this.displayText === fullTxt) {
      delta = 2000;
      this.isDeleting = true;
    } else if (this.isDeleting && this.displayText === '') {
      this.isDeleting = false;
      this.loopNum++;
      delta = 500;
    }

    setTimeout(() => this.typeEffect(), delta);
  }

}
