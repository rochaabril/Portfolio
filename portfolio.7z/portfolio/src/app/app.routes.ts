import { RouterModule, Routes } from '@angular/router';
import { ContactoComponent } from './contacto/contacto.component';
import { HomeComponent } from './home/home.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { ServiciosComponent } from './servicios/servicios.component';
import { SobpxiComponent } from './sobre-mi/sobre-mi.component';
import { ConocimietosComponent } from './conocimietos/conocimietos.component';


export const routes: Routes = [
  { path: '', component: HomeComponent,data: { animation: 'HomePage' }, }, // Home por defecto
  { path: 'sobre-mi', component: SobpxiComponent, data: { animation: 'SobpxiPage' }, },
  { path: 'portfolio', component: PortfolioComponent,   data: { animation: 'PortfolioPage' }, },
  { path: 'servicios', component: ServiciosComponent,  data: { animation: 'ServiciosPage' }, },
  { path: 'conocimientos', component: ConocimietosComponent,   data: { animation: 'ConocimientosPage' }, },
  { path: 'contacto', component: ContactoComponent,   data: { animation: 'ContactoPage' }, },
  { path: '**', redirectTo: '' } // ruta no encontrada -> Home
];
