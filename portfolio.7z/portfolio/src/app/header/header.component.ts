import { CommonModule } from '@angular/common';
import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-header',
  imports: [ RouterModule,CommonModule ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent   implements OnInit {
  @ViewChild('menuContainer') menuRef!: ElementRef;
  isMobile = false;
  menuOpen = false;

  ngOnInit() {
    this.checkScreenWidth();
    window.addEventListener('resize', () => this.checkScreenWidth());
  }

  checkScreenWidth() {
    this.isMobile = window.innerWidth <= 700;
    if (!this.isMobile) {
      this.menuOpen = false;
    }
  }

  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }

  @HostListener('document:click', ['$event'])
  handleClickOutside(event: Event) {
    if (this.isMobile && this.menuOpen && this.menuRef) {
      const clickedInside = this.menuRef.nativeElement.contains(event.target);
      if (!clickedInside) {
        this.menuOpen = false;
      }
    }
  }
}
