import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SobpxiComponent } from './sobre-mi.component';

describe('SobpxiComponent', () => {
  let component: SobpxiComponent;
  let fixture: ComponentFixture<SobpxiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SobpxiComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SobpxiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
