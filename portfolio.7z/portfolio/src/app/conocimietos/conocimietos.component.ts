import { Component } from '@angular/core';

@Component({
  selector: 'app-conocimietos',
  standalone: true,
  imports: [],
  templateUrl: './conocimietos.component.html',
  styleUrl: './conocimietos.component.css'
})
export class ConocimietosComponent {

}
