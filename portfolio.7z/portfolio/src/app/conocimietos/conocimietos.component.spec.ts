import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConocimietosComponent } from './conocimietos.component';

describe('ConocimietosComponent', () => {
  let component: ConocimietosComponent;
  let fixture: ComponentFixture<ConocimietosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConocimietosComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConocimietosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
